<template>
  <div>
    <h2>QR Code Scanner</h2>
    <div>
      <video ref="video" width="400" height="300"></video>
    </div>
    <button @click="startScanner">Start Scanner</button>
  </div>
</template>

<script>
import axios from 'axios';
// import QrScanner from 'qr-scanner';

export default {
  // mounted() {
  //   QrScanner.WORKER_PATH = 'path-to-worker-script/qr-scanner-worker.min.js';
  //   this.scanner = new QrScanner(this.$refs.video);
  //   this.scanner.onScan(this.onScan);
  // },
  methods: {
    startScanner() {
      this.scanner.start();
    },
    onScan(result) {
      // Send scanned QR code to backend for login
      axios.post('http://localhost:5000/api/login', { qrCode: result })
        .then(response => {
          alert(response.data.message);
          // Redirect to employee dashboard
          // You can implement the redirection logic here using Vue Router
        })
        .catch(error => {
          console.error(error);
          alert('An error occurred while logging in.');
        });
    }
  }
};
</script>
