<template>
  <div class="">
    <v-data-table
      :headers="headers"
      :items="partialPayments"
      class="elevation-1 mt-5 ml-5"
    >
      <template v-slot:top>
        <v-toolbar flat>
          <div class="mix">
            <v-toolbar-title class="spl">Special Clients Data</v-toolbar-title>
            <v-btn
              style="background-color: #250361; color: white"
              @click="downloadCSV"
              >Download CSV</v-btn
            >
          </div>
          <v-divider class="mx-4" inset vertical></v-divider>
          <v-spacer></v-spacer>
        </v-toolbar>
      </template>
    </v-data-table>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "InterestedLeads",
  components: {},
  data: () => ({
    employeeName: "",
    partialPayments: [],
    headers: [
      // { title: "ID", value: "0" },
      { title: "Employee Name", value: "1" },
      { title: "Client Name", value: "4" },
      { title: "Branch Name", value: "2" },
      { title: "UpDated on", value: "3" },
      { title: "Segment", value: "8" },
      // { title: "payment_type", value: "9" },
    ],
  }),

  created() {
    this.employeeName = this.$route.params.employeeName;
    this.fetchPaymentClients();
  },

  methods: {
    fetchPaymentClients() {
      const role = "admin";
      axios
        .get(`https://api.tkrgroups.co.in//spcl/${role}`)
        .then((response) => {
          const clients = response.data.clients;
          console.log(response.data.clients);
          this.partialPayments = clients;
        });
    },

    downloadCSV() {
      const rows = [];
      // push the header row
      rows.push(this.headers.map((h) => h.title));
      // push the data rows
      this.partialPayments.forEach((item) => rows.push(Object.values(item)));
      // convert rows to CSV content
      const csvContent = rows.map((r) => r.join(",")).join("\n");
      // create a new Blob object with the CSV content
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      // create a download link and trigger click event to download
      const link = document.createElement("a");
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", "specialclients.csv");
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
    },
  },
};
</script>
<style scoped>
.spl {
  font-size: 1.8rem;
}
.mix {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
}
</style>
