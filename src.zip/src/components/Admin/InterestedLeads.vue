<template>
    <div class="">
      <AdminSidebar/>
    <div class="overflow-x-auto">
    
    
        <button @click="goBack" class="back mt-5"><v-icon>mdi-arrow-left-bold</v-icon></button>
        <v-data-table
          :headers="headers"
          :items="leads"
          
          class="elevation-1 mt-5"
        >
        
          <template v-slot:top>
            <v-toolbar
              flat
            >
            <v-toolbar-title v-if="status === 'Interested'">Interested clients</v-toolbar-title>
            <v-toolbar-title v-if="status === 'Free trail'">Free trail clients</v-toolbar-title>
            <v-toolbar-title v-if="status === 'Not Interested'">Not Interested clients</v-toolbar-title>
            <v-toolbar-title v-if="status === 'Follow up'">Follow up clients</v-toolbar-title>
            <v-toolbar-title v-if="status === 'Wrong Number'">Wrong Number clients</v-toolbar-title>
            <v-toolbar-title v-if="status === 'Busy/notpickup/Switchoff'">Busy/notpickup/Switchoff - clients</v-toolbar-title>

            <v-divider
                class="mx-4"
                inset
                vertical
              ></v-divider>
              <v-spacer></v-spacer>
              <!-- <v-dialog
                v-model="dialog"
                max-width="500px"
              >
                
      
              </v-dialog> -->
             
            </v-toolbar>
          </template>
       <template v-slot:[`item.actions`]="{ item }">
            <v-btn
              size="small"
              class="me-2"
              @click="editItem(item.raw)"
            >
              Payment
            </v-btn>
          
          </template> 
       
        </v-data-table></div>
        </div>
  </template> 
  <script>
  import axios from 'axios'
import AdminSidebar from './AdminSidebar.vue'

    export default {
      name:'InterestedLeads',
      
      components:
      {
        AdminSidebar
      },
      data: () => ({
       status:'',
       branch:'',
        dialog: false,
        dialogDelete: false,
        special: false,
        leads:[],
        date:'',
        fdate:'',
        updatedstatus:'',
        Asendto:'',
        employeeName :'',
        partialamount:'',
        payment:null,
      paymentype:'',
        paymentoption:['Full','Partial','Future'],
        pstatus:['completed','partiallycompleted','Future'],
          headers: [
          // {
          //   title: 'lead id',
          //   align: 'start',
          //   sortable: false,
          //   key: '0',
          // },
          { title: 'Employee Name', key: '9' },
          { title: 'Branch', key: '7' },
          { title: 'clientname', key: '5' },
          { title: 'Language', key: '6' },
          { title: 'date', key: '8' },
          { title: 'Segment', key: '4' },
          // { title: 'status', key: '1' },
          // { title: 'Actions', key: 'actions', sortable: false },
        ],
       
        // desserts: [],
       
        editedIndex: -1,
        editedItem: {
          0: '',
          client: 0,
          date: 0,
          amount: 0,
          status: 0,
        },
        defaultItem: {
        0: '',
          client: 0,
          date: 0,
          amount: 0,
          status: 0,
        },
        items: [
      "completed","Partial","Future"
    ],
      }),
  
      computed: {
        formTitle () {
          return this.editedIndex === -1 ? 'New Item' : 'Edit Item'
        },
      },
  
      watch: {
        dialog (val) {
          val || this.close()
        },
       
      },
  
      created () {
        
        this.status = this.$route.query.status;
        // this.status = this.$route.query.status;
        this.branch = this.$route.query.Branch;
     
      
        this.interestedlead()
        
      },
    
      methods: {
       

        interestedlead()
      {
        
        const status='interested';
  axios.post('https://api.tkrgroups.co.in//leads/status',
  {
  status:status})
    .then(response => {
      this.leads=response.data.leads;
      console.log(this.leads)
     
    });
      },
  
        goBack() {
      this.$router.go(-1)
    },
      
        editItem (item) {
          
          this.editedIndex = this.leads.indexOf(item)
          this.editedItem = Object.assign({}, item)
          this.dialog = true
          this.selecteditem=item
          console.log(this.selecteditem[1])
        },
  
        
  
        close () {
          this.dialog = false
          this.$nextTick(() => {
            this.editedItem = Object.assign({}, this.defaultItem)
            this.editedIndex = -1
          })
        },
  
        
  
        save () {
          
          axios.post('https://api.tkrgroups.co.in//intcl/payments', {
            emp_name:this.employeeName,

        date:this.date,
        fdate:this.fdate,
        special: this.special ? 'special' : 'regular',
        client_name:this.selecteditem[5],
        amount:this.selecteditem[4],
        partialamount:this.partialamount,
        amount_sentto:this.Asendto,
        number:this.selecteditem[2],
        amount_receivedby:this.selecteditem[9],
        paytype:this.paymentype,
        // paystatus:this.payment,
        language:this.selecteditem[6],
        updatedstatus:this.updatedstatus,
        branch:this.selecteditem[7]

        
      })
        .then(response => {
         console.log(response.data)});
         this.dialogVisible = false;
       

   

        
        },
      },
    }
  </script> 
  <style scoped>
  .intl
  {

    margin-left: 3rem;
    width: 80rem;
  }
  .back
{
  background:white;
      color:black;
      font-size: 1rem;
      border-radius: 30px;
      height: 3rem;
      width: 3rem;
      box-shadow: 3px 3px 3px 3px #9999 ;
}
  </style>
  
   
  