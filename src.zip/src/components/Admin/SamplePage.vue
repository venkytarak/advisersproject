<template>
  <div class="">
    <AdminSidebarVue />
    <div class="mt-5">
      <!-- <button @click="goBack" class="back mt-5"><v-icon>mdi-arrow-left-bold</v-icon></button> -->
      <v-data-table
        :headers="headers"
        :items="employees"
        :sort-by="[{ key: 'name', order: 'asc' }]"
        class="elevation-1 ml-5 hdr"
        :header-class="'header-background'"
      >
        <template v-slot:top>
          <v-toolbar flat>
            <v-toolbar-title class="toolbar-title"
              >Employees Details</v-toolbar-title
            >

            <v-btn
              style="background-color: #250361; color: white"
              @click="downloadCSV"
              >Download CSV</v-btn
            >

            <v-divider class="mx-4" inset vertical></v-divider>
            <!-- <v-spacer></v-spacer> -->
            <button class="empbtn" @click="addEmpModal = !addEmpModal">
              AddEmployee
            </button>

            <VDialog v-model="addEmpModal">
              <VCard>
                <VCardTitle>Add Employees</VCardTitle>
                <VCardText>
                  <VForm>
                    <VTextField label="Employee Name" v-model="empname" />
                    <VTextField label="Employee email" v-model="empemail" />
                    <VTextField
                      label="Employee password"
                      v-model="emppassword"
                    />
                    <!-- <VTextField label="Employee branch" v-model="newEmployee" /> -->
                    <VSelect
                      label="Assign to branch"
                      required
                      v-model="selectedBranch"
                      :items="branchname"
                      item-text="name"
                      item-value="id"
                    />
                  </VForm>
                </VCardText>

                <VCardActions>
                  <VBtn text @click="addEmpModal = false">Cancel</VBtn>
                  <VBtn text @click="addemp">Add</VBtn>
                </VCardActions>
              </VCard>
            </VDialog>
          </v-toolbar>
        </template>
        <template v-slot:[`item.actions`]="{ item }">
          <v-icon size="small" class="me-2" @click="editItem(item.raw)">
            mdi-pencil
          </v-icon>
        </template>
      </v-data-table>
      <v-dialog v-model="showQRCodeDialog" max-width="500px">
        <v-card>
          <v-card-title>QR Code</v-card-title>
          <v-card-text>
            <img :src="qrCode" alt="QR Code" v-if="qrCode" />
          </v-card-text>
          <v-card-actions>
            <v-btn text @click="showQRCodeDialog = false">Close</v-btn>
            <v-btn text @click="downloadQRCode">Download</v-btn>
          </v-card-actions>
        </v-card>
      </v-dialog>
    </div>
  </div>
</template>
<script>

import axios from "axios";
import AdminSidebarVue from "./AdminSidebar.vue";
import Swal from 'sweetalert2'
export default {
  name: "InterestedLeads",
  components: {
    AdminSidebarVue,
  },

  data: () => ({
    addEmpModal: false,
    showQRCodeDialog:false,
    qrCode : '',

    empname: "",
    empemail: "",
    emppassword: "",
    selectedBranch: "",
    employees: [],
    dialog: false,
    dialogDelete: false,
    branchname: [],
    qrcodeImage :'',

    headers: [
      // { title: "Id", key: "0" },
      
      { title: "user Name", key: "0" },
      { title: "Email", key: "1" },
      { title: "password", key: "2" },
      {
        title: "Branch",
        align: "start",
        sortable: false,
        key: "3",
      },

      { title: "role", key: "4" },
      // { title: "Chat", key: "" },
      // { title: 'Actions', key: 'actions', sortable: false },
    ],
    desserts: [],
    editedIndex: -1,
    editedItem: {
      empid: "",
      name: 0,
      branch: 0,
      mail: 0,
      role: 0,
    },
    defaultItem: {
      empid: "",
      name: 0,
      branch: 0,
      mail: 0,
      role: 0,
    },
    items: ["Manager", "Employee"],
  }),

  computed: {
    formTitle() {
      return this.editedIndex === -1 ? "New Item" : "Edit Item";
    },
  },

  watch: {
    dialog(val) {
      val || this.close();
    },
  },

  created() {
    this.initialize();
    this.fetchemployees();
    this.fetchbranchname();
  },

  methods: {
    async fetchbranchname() {
      try {
        const { data } = await axios.get(
          "https://api.tkrgroups.co.in//apiget/branchename"
        );
        // this.managers = data.emp_list
        this.branchname = data.branch;

        console.log(this.branchname);
      } catch (error) {
        console.error(error);
      }
    },

    addemp() {
      
      axios
        .post("https://api.tkrgroups.co.in//insertemp", {
          name: this.empname,
          email: this.empemail,
          password: this.emppassword,
          branch: this.selectedBranch,
        }
        )
        .then((response) => {
         
          
//           this.qrCode = response.data;
//           this.addEmpModal=false,
//           this.qrcodeImage = `data:image/png;base64,${this.qrCode}`;

// const qrcodeElement = document.createElement('img');
// qrcodeElement.src = qrcodeImage;

// document.getElementById('qrcode-dialog').appendChild(qrcodeElement);

        
          //  this.qrCode = 'data:image/png;base64,' + response.data.qr_code;
        
          // this.downloadLink = response.data.download_link;
          this.showQRCodeDialog = true;
          Swal.fire({
        title: 'Success',
        text: 'Employee Added successfully',
        icon: 'success',
        confirmButtonText: 'OK'
      }).then(() => {
        location.reload();
      });
    
          // this.branches.push(response.data)
          // this.addBranchModal
          console.log(response.data);
        });
    },
    downloadQRCode() {
      const link = document.createElement('a');
      link.href = this.downloadLink;
      link.setAttribute('download', 'qr_code.png');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    },

    downloadCSV() {
      const rows = [];
      // push the header row
      rows.push(this.headers.map((h) => h.title));
      // push the data rows
      this.employees.forEach((item) => rows.push(Object.values(item)));
      // convert rows to CSV content
      const csvContent = rows.map((r) => r.join(",")).join("\n");
      // create a new Blob object with the CSV content
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      // create a download link and trigger click event to download
      const link = document.createElement("a");
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", "employees.csv");
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    },

    goBack() {
      this.$router.go(-1);
    },
    initialize() {},

    editItem(item) {
      this.editedIndex = this.desserts.indexOf(item);
      this.editedItem = Object.assign({}, item);
      this.dialog = true;
    },

    deleteItem(item) {
      this.editedIndex = this.desserts.indexOf(item);
      this.editedItem = Object.assign({}, item);
      this.dialogDelete = true;
    },

    deleteItemConfirm() {
      this.desserts.splice(this.editedIndex, 1);
      this.closeDelete();
    },

    close() {
      this.dialog = false;
      this.$nextTick(() => {
        this.editedItem = Object.assign({}, this.defaultItem);
        this.editedIndex = -1;
      });
    },

    closeDelete() {
      this.dialogDelete = false;
      this.$nextTick(() => {
        this.editedItem = Object.assign({}, this.defaultItem);
        this.editedIndex = -1;
      });
    },

    save() {
      if (this.editedIndex > -1) {
        Object.assign(this.desserts[this.editedIndex], this.editedItem);
      } else {
        this.desserts.push(this.editedItem);
      }
      this.close();
    },
    async fetchemployees() {
      const role = "admin"; // or 'admin'
      // const branchName = this.branchName; // applicable only for manager role
      axios
        .get(`https://api.tkrgroups.co.in//employees/${role}`)
        .then((response) => {
          this.employees = response.data.employees;
          console.log(this.employees);
        }) .then((response) => {
         
      
          console.log(response.data);


        })
        .catch((error) => {
          console.log(error);
        });
    },
  },
};
</script>
<style scoped>
.back {
  background: white;
  color: black;
  font-size: 1rem;
  border-radius: 30px;
  height: 3rem;
  width: 3rem;
  box-shadow: 3px 3px 3px 3px #9999;
}
.toolbar-title {
  color: #250361;
  /* height: 3rem;
  display: flex;
  justify-content: center;
  align-items: center; */
}
.empbtn {
  margin-left: 30rem;
  background: #250361;
  color: white;
  height: 2.2rem;
  width: 9rem;
  border-radius: 5px;
  margin-right: 3rem;
}
.header-background th {
  background-color: red;
}
</style>
