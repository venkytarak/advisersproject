<template>
  <canvas id="myChart"></canvas>
</template>

<script>
import Chart from "chart.js/auto";


export default {
  mounted() {
  const ctx = document.getElementById("myChart");

  fetch('https://api.tkrgroups.co.in//branch_counts')
    .then(response => response.json())
    .then(data => {
      const branches = Object.keys(data);
      const counts = Object.values(data);

      new Chart(ctx, {
        type: "bar",
        data: {
          labels: branches,
          datasets: [
            {
              label: "Top  sales",
              data: counts,
              borderWidth: 1,
              backgroundColor: "#a96292",
              borderColor: "#a96292",
            },
          ],
        },
        options: {
          scales: {
            y: {
              beginAtZero: true,
            },
          },
        },
      });
    })
    .catch(error => console.error(error));
}

  // mounted() {
  //   const ctx = document.getElementById("myChart");

  //   new Chart(ctx, {
  //     type: "bar",
  //     data: {
  //       labels: [
  //         "B-1",
  //         "B-2",
  //         "B-3",
  //         "B-5",
  //         "B-6",
  //         "B-7",
  //         "B-8",
  //         "B-9",
  //         "B-10",
  //         "B-11",
  //       ],
  //       datasets: [
  //         {
  //           label: "Completed Leads",
  //           data: [12, 19, 3, 5, 12, 3, 10, 15, 25, 35, 14],
  //           borderWidth: 1,
  //           backgroundColor: "#a96292",
  //           borderColor: "#a96292",
  //         },
  //       ],
  //     },
  //     options: {
  //       scales: {
  //         y: {
  //           beginAtZero: true,
  //         },
  //       },
  //     },
  //   });
  // },
};
</script>
