<template>
  <nav>
    <v-navigation-drawer class="navigm" v-model="drawer">
      <v-list-item
        prepend-avatar="https://example.com/images/person_illustrations/12345.png"
        :title="managername"
        subtitle="(Manager)"
        style="color: black"
        nav
      >
        <template v-slot:append>
          <v-btn
            variant="text"
            icon="mdi-chevron-left"
            @click.stop="drawer = !drawer"
          ></v-btn>
        </template>
      </v-list-item>

      <v-divider></v-divider>

      <v-list density="compact" nav>
        <v-list-item
          style="color: black"
          :to="'/MgHome/' + branchname + '/' + managername"
          prepend-icon="mdi-view-dashboard"
          title="Dashboard"
          value="account"
          class="mt-5"
        ></v-list-item>
        <!-- <v-list-item
          style="color: black"
          to="/RequestLead"
          prepend-icon="mdi-view-dashboard"
          title="Request Lead"
          value="account"
          class="mt-2"
        ></v-list-item> -->
        <!-- <v-list-item
          style="color: black"
          :to="'/Target/'+ branchname + '/' + managername"
          prepend-icon="mdi-calendar-month"
          title="targets"
          value="Monthly Sales"
          class="mt-5"
        ></v-list-item> -->
        <v-list-item
          style="color: black"
          :to="'/ML/' + branchname + '/' + managername"
          prepend-icon="mdi-account-multiple"
          title="Leads"
          value="Leads"
          class="mt-5"
        ></v-list-item>
        <v-list-item
          style="color: black"
          :to="'/mngemp/' + branchname + '/' + managername"
          prepend-icon="mdi-account-group"
          title="Employees"
          value="Employees"
          class="mt-5"
        ></v-list-item>
        <v-list-item
          style="color: black"
          :to="'/Payment/' + branchname + '/' + managername"
          prepend-icon="mdi-credit-card"
          title="Payment Clients"
          value="Payment Clients"
          class="mt-5"
        ></v-list-item>
        <v-list-item
          style="color: black"
          :to="'/splc/' + branchname + '/' + managername"
          prepend-icon="mdi-home-city"
          title="Special Clients"
          value="Special Clients"
          class="mt-5"
        ></v-list-item>
        <v-list-item
          style="color: black"
          :to="'/dnd/' + branchname + '/' + managername"
          prepend-icon="mdi-minus-circle"
          title="Add Dnd"
          value="dnd"
          class="mt-5"
        ></v-list-item>
        <!-- <v-list-item
          style="color: black"
          to="/MgSet"
          prepend-icon="mdi-wrench"
          title="Settings"
          value="Settings"
          class="mt-5"
        ></v-list-item> -->
      </v-list>
    </v-navigation-drawer>

    <v-toolbar app color="#def1fe" dark>
      <v-btn icon @click="drawer = !drawer">
        <v-icon class="menuicon">mdi-menu</v-icon>
      </v-btn>

      <v-toolbar-title>
        <a :href="'/MgHome/' + branchname + '/' + managername">
          <img src="/trklogo.jfif" alt="Logo" class="logo-img" />
        </a>
      </v-toolbar-title>

      <v-spacer></v-spacer>
      <v-btn stacked>
        <v-badge color="red" content="0">
          <v-icon color="black">mdi-bell</v-icon>
        </v-badge>
      </v-btn>
      <v-btn color="#ddddd" variant="tonal" @click="logout">
        <v-icon color="black" icon="mdi-login"></v-icon>

        <p style="color: black">Logout</p>
      </v-btn>

      <!-- Additional toolbar items go here -->
    </v-toolbar>
  </nav>
</template>

<script>
import Swal from 'sweetalert2'
export default {
  name: "ManagerSidebar",
  data() {
    return {
      drawer: true,
      branchname: "",
      managername: "",
    };
  },
  created() {
    this.branchname = this.$route.params.branchName;
    this.managername = this.$route.params.manager;
  },
  methods: {
  logout() {
    // Show confirmation dialog
    Swal.fire({
      title: 'Are you sure you want to logout?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, logout!',
      cancelButtonText: 'Cancel'
    }).then((result) => {
      if (result.isConfirmed) {
        // User confirmed, logout the user
        // Call your backend API to log out the user
        // axios.post('https://api.tkrgroups.co.in/logout')
        //   .then(() => {
            // Logout successful, redirect to login page
          //   window.location.href = '/login';
          // })
          // .catch((error) => {
          //   console.log(error);
          // });
          window.location.href = '/';
      }
    });
  }
}

};
</script>

<style>
.navigm {
  background: #def1fe;
}
.logo-img {
  width: 55px;
  height: 55px;
  border-radius: 50px;
}
.menuicon {
  color: black;
}
.navigation {
  background-color: #def1fe;
}
.navi {
  color: white;
}
</style>
