<template>
  <v-container>
    <v-row justify="center" class="lf">
      <v-col cols="12" md="6" lg="4" sm="10">
        <v-card class="login">
          <v-card-title class="text-center">Login Form</v-card-title>

          <v-card-text>
            <v-img src="/trklogo.jfif" aspect-ratio="2.5"></v-img> 
            <v-form ref="loginForm" @submit.prevent="login">
              <v-text-field v-model="name" label="Username"></v-text-field>
              <v-text-field
                v-model="password"
                :append-icon="showPassword ? 'mdi-eye' : 'mdi-eye-off'"
                :type="showPassword ? 'text' : 'password'"
                label="Password"
                @click:append="showPassword = !showPassword"
              >
              </v-text-field>
              <v-btn type="submit" color="primary" block>Login</v-btn>
            </v-form>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from "axios";
import Swal from "sweetalert2";


export default {
  data() {
    return {
      name: "",
      password: "",
      showPassword: false,
    };
  },
  methods: {
    async login() {
      const loginTime = new Date().toISOString()
  
  console.log(`Username: ${this.name}, Password: ${this.password}`);
  try {
    const response = await axios.post('https://api.tkrgroups.co.in//api/login', {
      name: this.name,
      password: this.password,
      login_time: loginTime
    })
    if (response.data.status === 'success') {
      localStorage.setItem('isLoggedIn', true);
      localStorage.setItem('userRole', response.data.role);
      localStorage.setItem('userStatus', response.data.status);
      localStorage.setItem('token', response.data.token);
      if (response.data.role === 'admin') {
        this.$router.push('/AdHome')
      } else if (response.data.role === 'manager') {
        const branchName = response.data.branch;
        const manager = response.data.manager;
        this.$router.push({ name: 'mghome', params: { branchName, manager }});
      } else if (response.data.role === 'emp') {
        const employeeName = response.data.emp_name;
       
        this.$router.push(`/emphome/${employeeName}`);
      }
      Swal.fire({
        icon: 'success',
        title: 'Signed in successfully',
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
          toast.addEventListener('mouseenter', Swal.stopTimer)
          toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
      })
    } else {
      await Swal.fire({
        icon: 'error',
        title: 'Invalid credentials',
        showConfirmButton: false,
        timer: 1500
      })
    }
  } catch (error) {
    console.error(error)
    await Swal.fire({
      icon: 'error',
      title: 'Login Failed',
      text: error.message,
      showConfirmButton: true,
      confirmButtonText: 'OK'
    })
  }
}
    
  
  },
};
</script>

<style>
.lf {
  height: 100vh;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}

.login {
  background: rgba(255, 255, 255, 0.25);
  border: 4px solid rgba(255, 255, 255, 0.25);
  background: blur(20px);
}

</style>
